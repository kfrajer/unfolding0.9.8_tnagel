/**
 * Contains map projections, and the geo-spatial Location bean.
 */
package de.fhpotsdam.unfolding.geo;

