/**
 * General utility functions.
 */
package de.fhpotsdam.utils;
